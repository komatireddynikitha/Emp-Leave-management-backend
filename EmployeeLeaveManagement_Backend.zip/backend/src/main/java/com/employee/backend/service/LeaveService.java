package com.employee.backend.service;

import com.employee.backend.entity.LeaveApplication;
import com.employee.backend.repository.LeaveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class LeaveService {
    private final LeaveRepository repository;

    public LeaveService(LeaveRepository repository) {
        this.repository = repository;
    }

    public List<LeaveApplication> getAll() {
        return repository.findAll();
    }

    public List<LeaveApplication> getByEmail(String email) {
        return repository.findByEmployeeEmailIgnoreCaseOrderByIdDesc(email);
    }

    @Transactional
    public LeaveApplication create(LeaveApplication leave) {
        validateDates(leave.getStartDate(), leave.getEndDate());
        leave.setEmployeeEmail(leave.getEmployeeEmail().trim().toLowerCase());
        leave.setReason(leave.getReason().trim());
        leave.setStatus("PENDING");
        return repository.save(leave);
    }

    @Transactional
    public LeaveApplication update(Long id, LeaveApplication updated) {
        LeaveApplication leave = repository.findById(id)
            .orElseThrow(() -> new LeaveNotFoundException(id));
        validateDates(updated.getStartDate(), updated.getEndDate());
        if (!"PENDING".equals(leave.getStatus())) {
            throw new IllegalStateException("Only pending applications can be edited.");
        }
        leave.setStartDate(updated.getStartDate());
        leave.setEndDate(updated.getEndDate());
        leave.setReason(updated.getReason().trim());
        return repository.save(leave);
    }

    @Transactional
    public LeaveApplication updateStatus(Long id, String status) {
        if (!List.of("APPROVED", "REJECTED").contains(status)) {
            throw new IllegalArgumentException("Status must be APPROVED or REJECTED.");
        }
        LeaveApplication leave = repository.findById(id)
            .orElseThrow(() -> new LeaveNotFoundException(id));
        leave.setStatus(status);
        return repository.save(leave);
    }

    public void delete(Long id) {
        LeaveApplication leave = repository.findById(id)
            .orElseThrow(() -> new LeaveNotFoundException(id));
        if (!"PENDING".equals(leave.getStatus())) {
            throw new IllegalStateException("Only pending applications can be deleted.");
        }
        repository.delete(leave);
    }

    private void validateDates(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            throw new IllegalArgumentException("Start and end dates are required.");
        }
        if (end.isBefore(start)) {
            throw new IllegalArgumentException("End date cannot be before start date.");
        }
    }
}
