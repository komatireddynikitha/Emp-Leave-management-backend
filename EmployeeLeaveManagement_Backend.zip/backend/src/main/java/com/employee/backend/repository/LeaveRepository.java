package com.employee.backend.repository;

import com.employee.backend.entity.LeaveApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LeaveRepository extends JpaRepository<LeaveApplication, Long> {
    List<LeaveApplication> findByEmployeeEmailIgnoreCaseOrderByIdDesc(String employeeEmail);
}
