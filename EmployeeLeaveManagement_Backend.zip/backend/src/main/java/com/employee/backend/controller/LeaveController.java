package com.employee.backend.controller;

import com.employee.backend.entity.LeaveApplication;
import com.employee.backend.service.LeaveService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/leaves")
@CrossOrigin(origins = "http://localhost:5173")
public class LeaveController {
    private final LeaveService service;

    public LeaveController(LeaveService service) {
        this.service = service;
    }

    @GetMapping
    public List<LeaveApplication> getAll() {
        return service.getAll();
    }

    @GetMapping("/employee")
    public List<LeaveApplication> getByEmail(@RequestParam String email) {
        return service.getByEmail(email);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LeaveApplication create(@Valid @RequestBody LeaveApplication leave) {
        return service.create(leave);
    }

    @PutMapping("/{id}")
    public LeaveApplication update(@PathVariable Long id,
                                   @Valid @RequestBody LeaveApplication leave) {
        return service.update(id, leave);
    }

    @PatchMapping("/{id}/status")
    public LeaveApplication updateStatus(@PathVariable Long id,
                                         @RequestParam String status) {
        return service.updateStatus(id, status.toUpperCase());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> badRequest(IllegalArgumentException ex) {
        return Map.of("error", ex.getMessage());
    }

    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String, String> conflict(IllegalStateException ex) {
        return Map.of("error", ex.getMessage());
    }

    @ExceptionHandler(com.employee.backend.service.LeaveNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, String> notFound(RuntimeException ex) {
        return Map.of("error", ex.getMessage());
    }
}
