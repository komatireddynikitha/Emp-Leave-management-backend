package com.employee.backend.service;

public class LeaveNotFoundException extends RuntimeException {
    public LeaveNotFoundException(Long id) {
        super("Leave application not found: " + id);
    }
}
